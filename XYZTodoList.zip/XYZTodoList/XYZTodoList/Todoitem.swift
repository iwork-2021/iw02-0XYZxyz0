//
//  Todoitem.swift
//  XYZTodoList
//
//  Created by nju on 2021/10/30.
//

import UIKit

class Todoitem: NSObject,Encodable,Decodable{
    var title:String
    var isChecked:Bool
    
    init(title:String,isChecked:Bool){
        self.isChecked = isChecked
        self.title = title
    }
}
