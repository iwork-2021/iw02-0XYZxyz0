//
//  ItemViewController.swift
//  XYZTodoList
//
//  Created by nju on 2021/10/30.
//

import UIKit

protocol AddItemDelegate{
    func addItem(item: Todoitem)
}

protocol EditItemDelegate {
    func editItem(newItem: Todoitem, itemIndex: Int)
}

class ItemViewController: UIViewController {
    @IBOutlet weak var DoneButtom: UIButton!
    @IBOutlet weak var titleinput: UITextField!
    @IBOutlet weak var isChecked: UISwitch!
    
    var addItemDelegate: AddItemDelegate?
    var editItemDelegate: EditItemDelegate?
    var itemToEdit: Todoitem?
    var itemIndex: Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        DoneButtom.isEnabled = false
        if itemToEdit != nil {
            DoneButtom.isEnabled = true
            self.titleinput.text! = itemToEdit!.title
            self.isChecked.isOn = itemToEdit!.isChecked
        }
    }
    @IBAction func Cancel(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    @IBAction func Done(_ sender: Any) {
        if itemToEdit == nil {
            self.addItemDelegate?.addItem(item: Todoitem(title: titleinput.text!, isChecked: isChecked.isOn))
        } else {
            self.editItemDelegate?.editItem(newItem: Todoitem(title: titleinput.text!, isChecked: isChecked.isOn), itemIndex: self.itemIndex)
        }
        self.dismiss(animated: true, completion: nil)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

extension ItemViewController: UITextFieldDelegate{
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        let oldText = textField.text!
        let stringRange = Range(range, in:oldText)!
        let newText = oldText.replacingCharacters(in: stringRange, with: string)
        DoneButtom.isEnabled = !newText.isEmpty
        return true
    }
}
